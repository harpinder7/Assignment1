<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
body{
    background: grey;
    height: 100%;
    display: flex;
}
header{
    margin-top: 0px;
    position: absolute;
    width: 100%;
    display: inline;
    background-color: aqua;
    height: 1cm;
    font-size: 40px;
}
.container{
    margin-top: 10%;
    height: 90%;
    width: 90%;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px,1fr));
    grid-gap: 20px;
}
.info{
    height: 280px;
    color: white;
    border: 2px solid white;
    border-radius: 6px;
    position: relative;
}
.Week1{
    height: 280px;
    color: white;
    border: 2px solid white;
    border-radius: 6px;
    position: relative;
}
.Week2{
    height: 280px;
    color: white;
    border: 2px solid white;
    border-radius: 6px;
    position: relative;
}
.Week3{
    height: 280px;
    color: white;
    border: 2px solid white;
    border-radius: 6px;
    position: relative;
}
.Week4{
    height: 280px;
    color: white;
    border: 2px solid white;
    border-radius: 6px;
    position: relative;
}


.Final{
    height: 280px;
    color: white;
    border: 2px solid white;
    border-radius: 6px;
    position: relative;
}

</style>
</head>
<body>
    <header>Punching Panel Analysis</header>
    <div class="container">
        <div class="info">
        <form action="info.php" method="post">
            <h1>INFO</h1>
            <label>Employee_ID</label>
            <input type="text" id="Employee_ID" name="Employee_ID" required><br><br>
            <label>Employee_Name:</label>
            <input type="text" id="Employee_name" name="Employee_name" required><br><br>
            <label>Email:</label>
            <input type="text" id="Email" name="Email" required><br><br>
            <label>Phone_number</label>
            <input type="number" id="Phone_number" name="Phone_number" required><br><br>
            <input type="submit" value="submit" text-align="center">
        </form>
        </div>
        <div class="Week1">
        <form action="Week1.php" method="post">
            <h1>Week 1</h1>
            <label>Employee_ID</label>
            <input type="text" id="Employee_ID" name="Employee_ID" required><br><br>
            <label>Attendance</label>
            <input type="number" id="Attendance" name="Attendance" required><br><br>
            <label>Rate</label>
            <input type="number" id="Rate" name="Rate" required><br><br>
            <label>Missing_hours</label>
            <input type="number" id="Missing_hours" name="Missing_hours" required><br><br>
            <input type="submit" value="submit" text-align="center">
        </form>
        </div>
        <div class="Week2">
        <form action="Week2.php" method="post">
            <h1>Week 2</h1>
            <label>Employee_ID</label>
            <input type="text" id="Employee_ID" name="Employee_ID" required><br><br>
            <label>Attendance</label>
            <input type="number" id="Attendance" name="Attendance" required><br><br>
            <label>Rate</label>
            <input type="number" id="Rate" name="Rate" required><br><br>
            <label>Missing_hours</label>
            <input type="number" id="Missing_hours" name="Missing_hours" required><br><br>
            <input type="submit" value="submit" text-align="center">
        </form>
        </div>
        <div class="Week3">
        <form action="Week3.php" method="post">
            <h1>Week 3</h1>
            <label>Employee_ID</label>
            <input type="text" id="Employee_ID" name="Employee_ID" required><br><br>
            <label>Attendance</label>
            <input type="number" id="Attendance" name="Attendance" required><br><br>
            <label>Rate</label>
            <input type="number" id="Rate" name="Rate" required><br><br>
            <label>Missing_hours</label>
            <input type="number" id="Missing_hours" name="Missing_hours" required><br><br>
            <input type="submit" value="submit" text-align="center">
        </form>
        </div>

        <div class="Week4">
        <form action="Week4.php" method="post">
            <h1>Week 4</h1>
            <label>Employee_ID</label>
            <input type="text" id="Employee_ID" name="Employee_ID" required><br><br>
            <label>Attendance</label>
            <input type="number" id="Attendance" name="Attendance" required><br><br>
            <label>Rate</label>
            <input type="number" id="Rate" name="Rate" required><br><br>
            <label>Missing_hours</label>
            <input type="number" id="Missing_hours" name="Missing_hours" required><br><br>
            <input type="submit" value="submit" text-align="center">
        </form>
        </div>
        <div class="Final">
        <form action="Final.php" method="post">
            <h1>FINAL</h1>
            <label>Employee_ID</label>
            <input type="text" id="Employee_ID" name="Employee_ID" required><br><br>
            <label>Attendance</label>
            <input type="number" id="Attendance" name="Attendance" required><br><br>
            <label>Rate</label>
            <input type="number" id="Rate" name="Rate" required><br><br>
            <label>Missing_hours</label>
            <input type="number" id="Missing_hours" name="Missing_hours" required><br><br>
            <input type="submit" value="submit" text-align="center">
        </form>
        </div>
    </div>
</body>
</html>