<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
    body{
        background-color: #202020;
    }
table {
    border-collapse: collapse;
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    text-align: center;
}

th {
  background-color: #f2f2f2;
  color: #333;
  padding: 8px;
  text-align: center;
}

td {
  background-color: #fff;
  width: 4%;
  color: #333;
  padding: 8px;
  text-align: center;
  border: 1px solid #ccc;
}

tr {
  display: block;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  padding: 10px;
}

    </style>
</head>
<body>
    
</body>
</html>
<?php
$my_table=['term1'];
// connect to the database (replace with your own connection code)
$servername = "localhost";
$username = "Harpinder";
$password = "Harpinder";
$dbname = "work";

$conn = mysqli_connect($servername, $username, $password, $dbname);

$row_id = $_GET['id'];

  





// display data for Week 1
$stmt = mysqli_prepare($conn, "SELECT * FROM term1 WHERE student_id = ?");
mysqli_stmt_bind_param($stmt, "i", $row_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    while ($row = mysqli_fetch_assoc($result)) {
      echo "<th> Term 1";
      echo "<tr>";
      echo "<td>" . "Employee ID: <br>".$row["Employee_ID"] . "</td>";
      echo "<td>" . "Attendance: <br>". $row["Attendance"] . "</td>";
      echo "<td>" . "Rate: <br>".$row["Rate"] . "</td>";
      echo "<td>" . "Missing hours: <br>". $row["Missing_hours"] . "</td>";
      
      // add additional columns here as needed
      echo "</tr>";
      echo "</th>";
    }
    echo "</table>";
  } 
  // display data for Week 2
  $stmt = mysqli_prepare($conn, "SELECT * FROM term1 WHERE student_id = ?");
  mysqli_stmt_bind_param($stmt, "i", $row_id);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  
  if (mysqli_num_rows($result) > 0) {
      echo "<table>";
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<th> Term 1";
        echo "<tr>";
        echo "<td>" . "Employee ID: <br>".$row["Employee_ID"] . "</td>";
        echo "<td>" . "Attendance: <br>". $row["Attendance"] . "</td>";
        echo "<td>" . "Rate: <br>".$row["Rate"] . "</td>";
        echo "<td>" . "Missing hours: <br>". $row["Missing_hours"] . "</td>";
        
        // add additional columns here as needed
        echo "</tr>";
        echo "</th>";
      }
      echo "</table>";
    } 
  // display data for Week 3
  $stmt = mysqli_prepare($conn, "SELECT * FROM term1 WHERE student_id = ?");
  mysqli_stmt_bind_param($stmt, "i", $row_id);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  
  if (mysqli_num_rows($result) > 0) {
      echo "<table>";
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<th> Term 1";
        echo "<tr>";
        echo "<td>" . "Employee ID: <br>".$row["Employee_ID"] . "</td>";
        echo "<td>" . "Attendance: <br>". $row["Attendance"] . "</td>";
        echo "<td>" . "Rate: <br>".$row["Rate"] . "</td>";
        echo "<td>" . "Missing hours: <br>". $row["Missing_hours"] . "</td>";
        
        // add additional columns here as needed
        echo "</tr>";
        echo "</th>";
      }
      echo "</table>";
    } 

// display data for Week 4
$stmt = mysqli_prepare($conn, "SELECT * FROM term1 WHERE student_id = ?");
mysqli_stmt_bind_param($stmt, "i", $row_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    while ($row = mysqli_fetch_assoc($result)) {
      echo "<th> Term 1";
      echo "<tr>";
      echo "<td>" . "Employee ID: <br>".$row["Employee_ID"] . "</td>";
      echo "<td>" . "Attendance: <br>". $row["Attendance"] . "</td>";
      echo "<td>" . "Rate: <br>".$row["Rate"] . "</td>";
      echo "<td>" . "Missing hours: <br>". $row["Missing_hours"] . "</td>";
      
      // add additional columns here as needed
      echo "</tr>";
      echo "</th>";
    }
    echo "</table>";
  } 


  
  // display data for final
$stmt = mysqli_prepare($conn, "SELECT * FROM final WHERE student_id = ?");
mysqli_stmt_bind_param($stmt, "i", $row_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<th> Final Term";
        echo "<tr>";
        echo "<td>" . "Employee ID: <br>".$row["Employee_ID"] . "</td>"."<br>";
        echo "<td>" . "Attendance: <br>". $row["attendance"] . "</td>";
        echo "<td>" . "Rate: <br>".$row["Rate"] . "</td>";
        echo "<td>" . "Missing hours: <br>". $row["Missing hours"] . "</td>";
      echo "</tr>";
      echo "</th>";
    }
    echo "</table>";
  }

// close the database connection
mysqli_close($conn);
?>
