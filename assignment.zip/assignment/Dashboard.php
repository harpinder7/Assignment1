<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
header{
  align-content: center;
  background-color: rgb(247, 188, 247);
  font-weight: bolder;  
}
.container{
    margin-top: 16px;
}
.container label{
    font-size: 20px;
    background: red;
}
.container select{
    margin-top: 19px;
    width: 30%;
}
.container select option{
    font-size: 20px;
}
.container input{
    width: 20%;
    margin-left: 20%;
}
.block{
    border: 1px solid black;
    padding: 10px;
    margin: 40px;
    display: inline-block;
    width: 40%;
}
</style>
</head>
<body>
    <header>
        <h1>Marble industries</h1>
        
    </header>
<main>
    <h2>Personal Data</h2>
    <div class="container">
    <form method="post">
        <label for="option"><h6>Select Month:</h6></label><br>
        <select id="option" name="option">
            <option value="option1">January</option>
            <option value="option2">Feburary</option>
            <option value="option3">March</option>
            <option value="option4">April</option>
            <option value="option5">May</option>
            <option value="option6">June</option>
            <option value="option7">July</option>
            <option value="option8">August</option>
            <option value="option9">September</option>
            <option value="option10">October</option>
            <option value="option11">November</option>
            <option value="option12">December</option>
        </select>
        <input type="submit" value="Submit">
    </form>
    </div>
</main>
</body>
</html>



<?php

// Define array for employees and the hours they worked
$data = array(
    'option1' => array('employees' => 100, 'Hours' => 8000),
    'option2' => array('employees' => 80, 'Hours' => 6400),
    'option3' => array('employees' => 120, 'Hours' => 9600),
    'option4' => array('employees' => 160, 'Hours' => 12800),
    'option5' => array('employees' => 150, 'Hours' => 12000),
    'option6' => array('employees' => 134, 'Hours' => 10720),
    'option7' => array('employees' => 154, 'Hours' => 12320),
    'option8' => array('employees' => 189, 'Hours' => 15498),
    'option9' => array('employees' => 144, 'Hours' => 11520),
    'option10' => array('employees' => 154, 'Hours' => 11620),
    'option11' => array('employees' => 189, 'Hours' => 12250),
    'option12' => array('employees' => 144, 'Hours' => 10250),
);

// Check for the option
if (isset($_POST['option'])) {
    $option = $_POST['option'];

    // Take information from the selected option
    $employees = $data[$option]['employees'];
    $Hours = $data[$option]['Hours'];

    // Display the data stored in the array 
    echo "<div class='block'>";
    echo "<h2>Number of employees: $employees</h2>";
    echo "</div>";
    echo "<div class='block'>";
    echo "<h2>Number of hours worked: $Hours</h2>";
    echo "</div>";
}

?>
