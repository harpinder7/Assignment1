<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>side</title>
<style>
    body{
        margin: 0;
    }
.side{
    position: absolute;
    background-color: rgb(20, 19, 19);
    height: 100%;
    width: 100%;
    }
.side ul{
    list-style-type: none;
    left: 0;
}
.side ul li{
    margin: 5px;
    padding: 5px;
    margin-top: 75px;
}
.side ul li a{
    color: white;
    text-decoration: none;
}
.side ul li a:hover{
    background-color: white;
    color: blue;
}
</style>
</head>
<body>
    <div class="side">
        <ul>
            <li><a href="dashboard.php" target="main">Dashboard</li>
            <li><a href="data.php" target="main">Add Data</li>
            <li><a href="Data-reflector.php" target="main">Data-reflector</li>
        </ul>
    </div>
</body>
</html>