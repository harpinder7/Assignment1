<?php
$Employee_ID=$_POST['Employee_ID'];
$Employee_Name=$_POST['Employee_Name'];
$Email=$_POST['email'];
$Phone_number=$_POST['Phone_number'];


if(!empty($Employee_ID)|| !empty($Employee_Name)|| !empty($Email) || !empty($Phone_number)){
    $host = "localhost";
    $dbUsername = "Harpinder";
    $dbPassword = "Harpinder";
    $dbname = "work";
    // connect to database
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
echo ("connection successful");

if (mysqli_connect_error()){
    die('Connection error('. mysqli_connect_error().')'. mysqli_connect_error());
}
else{
    $SELECT= "SELECT email From info Where email = ? Limit 1";
    $INSERT = "INSERT Into info (Employee_id, Employee_name, Email,Phone_number) values(?,?,?,?)";
    
    //Prepare Statements
    $stmt = $conn->prepare($SELECT);
    $stmt->bind_param("s",$Email);
    $stmt->execute();
    $stmt->bind_result($Email);
    $stmt->store_result();
    $rnum = $stmt->num_rows;

    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Employee_Name = $_POST['Employee_name'];
    $Email = $_POST['Email'];

    echo "Thank you for signing up, $Employee_Name! We will be sending all future communication to $Email.";
    }
}
if ($rnum==0){
    $stmt->close();

    $stmt = $conn-> prepare($INSERT);
    $stmt->bind_param("issss", $Employee_ID, $Employee_Name, $Email, $Phone_number);
    $stmt->execute();
    echo "New data is added successfully";
}
else{
    echo"Someone already registered with new email";
}
$stmt->close();
$conn->close();

}
?>