<?php
$Employee_ID = $_POST['Employee_id'];
$Attendance = $_POST['attendance'];
$Rate = $_POST['Rate'];
$Missing_hours = $_POST['Missing_hours'];

if(!empty($Employee_ID) && !empty($Attendance) && !empty($Rate) && !empty($Missing_hours)) {
    $host = "localhost";
    $dbUsername = "Harpinder";
    $dbPassword = "Harpinder";
    $dbname = "work";
    
    // connect to database
    $conn = 'new mysqli'($host, $dbUsername, $dbPassword, $dbname);

    if (mysqli_connect_error()) {
        die('Connection error('. mysqli_connect_error().')'. mysqli_connect_error());
    } else {
        $INSERT = "INSERT INTO Week3 (Employee_ID, attendance, Rate, Missing_hours) VALUES (?,?,?,?)";
        
        $stmt = $conn->prepare("SELECT * FROM term2 WHERE attendance = ?");
        $stmt->bind_param("i", $Attendance);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc())                
        
        $stmt->close();

        $stmt = $conn->prepare($INSERT);
        $stmt->bind_param("iiiii", $Employee_ID, $Attendance, $Rate, $Missing_hours);
        
        if ($stmt->execute()) {
            echo "New data is added successfully";
        } 
    }
}

    $stmt->close();
    $conn->close();
} else {
    echo "All fields are required";
}
?>
