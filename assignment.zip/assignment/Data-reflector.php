<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
.header{
    background-color: aqua;
    height: 1cm;
}
table {
border-collapse: collapse;
width: 100%;
color: grey;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
    <div class="header">
        <h1>Punching Panel Analysis</h1>
    </div>
    <table>
        <tr>
        <th>Details</th>
        <th>Employee_ID</th>
        <th>Employee_Name</th>
        <th>Email</th>
        <th>Phone_Number</th>
        </tr>
    <?php
    $host = "localhost";
    $dbUsername = "Harpinder";
    $dbPassword = "Harpinder";
    $dbname = "work";
    $conn = 'new mysqli'($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()){
        die('Connection error('. mysqli_connect_error().')'. mysqli_connect_error());
    }
    $sql = "SELECT * FROM work.info";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";     
            echo "<td>" . htmlspecialchars($row["id"]) .'<a href="show_more.php?id=' . htmlspecialchars($row["Employee_id"]) . '">'.
            "<input type='hidden' name='my_table' value='term1'>".
            "<button type='submit'>Show More</button></a>".
            "</form>"."</td>";
            echo "<td>" . htmlspecialchars($row["Employee_id"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["Employee_name"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["Phone_number"]) . "</td>";
            echo "</tr>";
        }
    }
    $conn->close();
    ?>
</body>
</html>